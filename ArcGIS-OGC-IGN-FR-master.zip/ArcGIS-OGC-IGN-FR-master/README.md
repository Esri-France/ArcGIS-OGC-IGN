# ArcGIS-OGC-IGN-FR
This repo is created to test OGC Services served by IGN in the ArcGIS Plateform
Context:

The IGN has Geoportal services : https://www.geoportail.gouv.fr/ 
The host is a departmental cloud and provider is ATOS => Thales.


Esri France has its own GeoServices, the vast majority of which are not IGN (IGN). They are very useful for all ArcGIS applications (tile images, vector, geocoding service, profiles, 3D services, offline mode, ...). As ArcGIS Services, those services can be consumed only in ArcGIS Plateform.
Esri France stopped this activity due to its complexity and heavy maintenance. 

Therefore Esri France wants to ensure that IGN GoeServices can be used in the ArcGIS Plateform. 
The min requirement is to ensure proper access to WMTS and WMS services. 

Esri, Esri France will work in this project. 

